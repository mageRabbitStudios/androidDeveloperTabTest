package com.example.stanislavkinzl.tabtestupdateddep.testsLocal.feature.testfeature_comicslist.widget

import androidx.test.runner.AndroidJUnit4
import org.junit.Test
import org.junit.runner.RunWith


@RunWith(AndroidJUnit4::class)
class ComicsListWidgetImplTest {

    @Test
    fun init() {

    }

    @Test
    fun initRecyclerView() {

    }

    @Test
    fun addResults() {

    }
}