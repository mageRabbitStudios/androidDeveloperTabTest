package com.example.stanislavkinzl.tabtestupdateddep.feature.feature_comicslist.widget.widget_marveltoolbar

import androidx.appcompat.app.AppCompatActivity
import android.view.View


interface ToolbarWidget {

    fun init(view: View)

    fun setToolbar(activity: AppCompatActivity)

}