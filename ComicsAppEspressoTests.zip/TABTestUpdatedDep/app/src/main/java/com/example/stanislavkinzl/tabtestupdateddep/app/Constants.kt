package com.example.stanislavkinzl.tabtestupdateddep.app


const val API_KEY = "d69b9581419ed36b6ef230f1f4e41fa4"
const val PRIVATE_KEY = "0b7ac65c6413040c06b6f0a8ac04251e4a3cf16e"
const val BASE_URL = "http://gateway.marvel.com/v1/public/"

const val NUMBER_OF_COMICS_PER_ROW_PORTRAIT = 3
const val NUMBER_OF_COMICS_PER_ROW_LANDSCAPE = 5
